# 2024-09-04T00:53:05.616086500
import vitis

client = vitis.create_client()
client.set_workspace(path="Z:/Xilinx/Projects/hdmi_zybo_tutorial/pynq_try/vitis")

comp = client.get_component(name="hello_world_2")
comp.build()

comp.build()

comp.build()

comp.build()

comp.build()

vitis.dispose()

