# 2024-08-28T20:01:11.345631500
import vitis

client = vitis.create_client()
client.set_workspace(path="Z:/Xilinx/Projects/hdmi_zybo_tutorial/pynq_try/vitis")

platform = client.create_platform_component(name = "platform",hw = "Z:/Xilinx/Projects/hdmi_zybo_tutorial/pynq_try/project_1/design_1_wrapper.xsa",os = "standalone",cpu = "ps7_cortexa9_0")

platform = client.get_platform_component(name="platform")
status = platform.build()

comp = client.create_app_component(name="hello_world",platform = "Z:/Xilinx/Projects/hdmi_zybo_tutorial/pynq_try/vitis/platform/export/platform/platform.xpfm",domain = "standalone_ps7_cortexa9_0",template = "hello_world")

comp = client.get_component(name="hello_world")
comp.build()

comp.build()

comp = client.get_component(name="hello_world")
status = comp.import_files(from_loc="Z:/Xilinx/Projects/hdmi_zybo_tutorial/Zybo-Z7-20-HDMI-sw.ide/Zybo-Z7-20-HDMI/src", files=["display_ctrl", "dynclk", "intc", "timer_ps", "video_capture"], dest_dir_in_cmp = "hello_world")

comp = client.get_component(name="hello_world")
comp.build()

status = comp.clean()

comp.build()

comp.build()

comp = client.get_component(name="hello_world")
status = comp.import_files(from_loc="Z:/Xilinx/Projects/hdmi_zybo_tutorial/Zybo-Z7-20-HDMI-sw.ide/Zybo-Z7-20-HDMI/src", files=["video_demo.c", "video_demo.h"], dest_dir_in_cmp = "src")

comp = client.get_component(name="hello_world")
comp.build()

comp = client.get_component(name="hello_world")
status = comp.import_files(from_loc="Z:/Xilinx/Projects/hdmi_zybo_tutorial/Zybo-Z7-20-HDMI-sw.ide/Zybo-Z7-20-HDMI/src", files=["display_ctrl", "dynclk", "intc", "timer_ps", "video_capture"], dest_dir_in_cmp = "src")

comp = client.get_component(name="hello_world")
comp.build()

comp.build()

comp.build()

comp.build()

status = comp.clean()

comp.build()

comp.build()

comp.build()

comp.build()

comp.build()

status = comp.clean()

comp.build()

comp.build()

status = comp.clean()

comp.build()

status = comp.clean()

comp.build()

status = comp.clean()

comp.build()

comp = client.create_app_component(name="empty_application",platform = "Z:/Xilinx/Projects/hdmi_zybo_tutorial/pynq_try/vitis/platform/export/platform/platform.xpfm",domain = "standalone_ps7_cortexa9_0",template = "empty_application")

comp = client.get_component(name="empty_application")
comp.build()

client.delete_component(name="empty_application")

comp = client.create_app_component(name="hello_world_2",platform = "Z:/Xilinx/Projects/hdmi_zybo_tutorial/pynq_try/vitis/platform/export/platform/platform.xpfm",domain = "standalone_ps7_cortexa9_0",template = "hello_world")

comp = client.get_component(name="hello_world_2")
comp.build()

comp.build()

comp = client.get_component(name="hello_world")
comp.build()

comp = client.create_app_component(name="empty_application",platform = "Z:/Xilinx/Projects/hdmi_zybo_tutorial/pynq_try/vitis/platform/export/platform/platform.xpfm",domain = "standalone_ps7_cortexa9_0",template = "empty_application")

comp = client.get_component(name="empty_application")
status = comp.import_files(from_loc="Z:/Xilinx/Projects/hdmi_zybo_tutorial/pynq_try/vitis/hello_world/src", files=["display_ctrl", "dynclk", "timer_ps"], dest_dir_in_cmp = "src")

status = comp.import_files(from_loc="Z:/Xilinx/Projects/hdmi_zybo_tutorial/pynq_try/vitis/hello_world/src", files=["display_demo.c", "display_demo.h"], dest_dir_in_cmp = "src")

comp = client.get_component(name="empty_application")
comp.build()

comp = client.get_component(name="hello_world_2")
status = comp.clean()

comp = client.get_component(name="hello_world")
status = comp.clean()

comp = client.get_component(name="empty_application")
comp.build()

comp.build()

comp = client.get_component(name="hello_world")
comp.build()

comp.build()

comp = client.get_component(name="empty_application")
comp.build()

comp.build()

comp.build()

comp.build()

comp = client.get_component(name="hello_world_2")
status = comp.import_files(from_loc="Z:/Xilinx/Projects/hdmi_zybo_tutorial/pynq_try/vitis/hello_world/src", files=["display_ctrl", "dynclk", "timer_ps"], dest_dir_in_cmp = "src")

status = comp.import_files(from_loc="Z:/Xilinx/Projects/hdmi_zybo_tutorial/pynq_try/vitis/hello_world/src", files=["display_demo.c", "display_demo.h"], dest_dir_in_cmp = "src")

comp = client.get_component(name="hello_world_2")
comp.build()

comp.build()

comp.build()

comp.build()

comp.build()

comp.build()

comp = client.get_component(name="hello_world_2")
status = comp.import_files(from_loc="Z:/Xilinx/Projects/hdmi_zybo_tutorial/pynq_try/vitis/hello_world/src/display_ctrl", files=["display_ctrl.c", "display_ctrl.h", "vga_modes.h", "xvtc.h", "xvtc_hw.h"], dest_dir_in_cmp = "src")

status = comp.import_files(from_loc="Z:/Xilinx/Projects/hdmi_zybo_tutorial/pynq_try/vitis/hello_world/src/dynclk", files=["dynclk.c", "dynclk.h"], dest_dir_in_cmp = "src")

status = comp.import_files(from_loc="Z:/Xilinx/Projects/hdmi_zybo_tutorial/pynq_try/vitis/hello_world/src/timer_ps", files=["timer_ps.c", "timer_ps.h"], dest_dir_in_cmp = "src")

comp = client.get_component(name="hello_world_2")
comp.build()

comp.build()

comp.build()

vitis.dispose()

